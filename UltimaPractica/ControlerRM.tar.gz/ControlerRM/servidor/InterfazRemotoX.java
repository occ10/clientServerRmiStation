import java.rmi.Remote;

public interface InterfazRemotoX extends Remote {
    public String Buscar(String palabra)  throws java.rmi.RemoteException;
   
}
